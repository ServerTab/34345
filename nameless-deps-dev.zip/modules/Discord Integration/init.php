<?php

require_once ROOT_PATH . '/modules/Discord Integration/module.php';

$module = new Discord_Module($language, $pages, $endpoints);
